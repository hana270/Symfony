<?php

// tests/Controller/ServiceControllerTest.php
namespace App\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ServiceControllerTest extends WebTestCase
{
    public function testServiceEndpoint(): void
    {
        $client = static::createClient();
        $client->request('GET', '/service');

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('body', 'Hello from your microservice!');
    }
}
