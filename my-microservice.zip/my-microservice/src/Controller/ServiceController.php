<?php

// src/Controller/ServiceController.php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;

class ServiceController
{
    public function index(): Response
    {
        // Your logic here
        $response = new Response('Hello from your microservice!');
        $response->headers->set('Content-Type', 'text/plain');
        return $response;
    }
}
