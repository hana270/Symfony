<?php

namespace App\Controller;

use App\Entity\Article;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;
use App\Form\ArticleType;
use Symfony\Component\Validator\Validator\ValidatorInterface;

use App\Entity\PriceSearch;
use App\Entity\Category;
use App\Form\CategoryType;
use App\Entity\PropertySearch;
use App\Form\PropertySearchType;
use  App\Entity\CategorySearch;
use App\Form\CategorySearchType;
use App\Repository\ArticleRepository; 

use App\Form\PriceSearchType; 

class IndexController extends AbstractController
{
    private $articleRepository; 
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager,ArticleRepository $articleRepository)
    {
        $this->entityManager = $entityManager;
        $this->articleRepository = $articleRepository;
    }
    /** * @Route("/article/save")*/
#[Route('/article/save', name: 'home')]
public function save()
{
    $category = $this->entityManager->getRepository(Category::class)->find($categoryId); // Remplacez $categoryId par l'ID de la catégorie appropriée

    if (!$category) {
        throw $this->createNotFoundException('Catégorie non trouvée');
    }

    $article = new Article();
    $article->setNom('Article 3');
    $article->setPrix(4000);
    $article->setCategory($category); // Assurez-vous que votre entité Article a une méthode setCategory()
    
    $this->entityManager->persist($article);
    $this->entityManager->flush();

    return new Response('Article enregistré avec id ' . $article->getId());
}

    /**
 *@Route("/",name="article_list")
 */
#[Route('/', name: 'article_list')]
public function home(Request $request, EntityManagerInterface $entityManager): Response // Injection de dépendance EntityManagerInterface
{
    $propertySearch = new PropertySearch();
    $form = $this->createForm(PropertySearchType::class, $propertySearch);
    $form->handleRequest($request);
    $articles = [];

    if ($form->isSubmitted() && $form->isValid()) {
        $nom = $propertySearch->getNom();
        if ($nom != "") {
            $articles = $entityManager->getRepository(Article::class)->findBy(['nom' => $nom]);
        } else {
            $articles = $entityManager->getRepository(Article::class)->findAll();
        }
    } else {
        $articles = $entityManager->getRepository(Article::class)->findAll();
    }
    return $this->render('articles/index.html.twig', [
        'form' => $form->createView(),
        'articles' => $articles
    ]);
}
/**
 * @Route("/article/new", name="new_article")
 * @Method({"GET", "POST"})
 */
#[Route('/article/new', name: 'new_article')]
public function new(Request $request): Response
{
    $article = new Article();
    $form = $this->createForm(ArticleType::class, $article);
    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        // Persist the article entity
        $this->entityManager->persist($article);
        $this->entityManager->flush();

        // Redirect to the article list after creation
        return $this->redirectToRoute('article_list');
    }

    // Render the form for creating a new article
    return $this->render('articles/new.html.twig', [
        'form' => $form->createView()
    ]);
}
/**
 * @Route("/article/{id}", name="article_show")
 */
#[Route('/article/{id}', name: 'article_show')]

public function show($id) {
    $article = $this->entityManager->getRepository(Article::class)->find($id);

    return $this->render('articles/show.html.twig', ['article' => $article]);
}

    /**
 * @Route("/article/edit/{id}", name="edit_article")
 * Method({"GET", "POST"})
 */
#[Route('/article/edit/{id}', name: 'edit_article')]
public function edit(Request $request, $id)
{
    $article = $this->entityManager->getRepository(Article::class)->find($id);

    if (!$article) {
        throw $this->createNotFoundException('Article non trouvé pour l\'id '.$id);
    }
    $form = $this->createForm(ArticleType::class, $article);
    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        $this->entityManager->flush();
        return $this->redirectToRoute('article_list');
    }

    return $this->render('articles/edit.html.twig', ['form' => $form->createView()]);
}
 

/**
 * @Route("/article/delete/{id}", name="delete_article")
 * @Method({"DELETE"})
 */

 #[Route('/article/delete/{id}', name: 'delete_article')]

public function delete(Request $request, $id, EntityManagerInterface $entityManager)
{
    $article = $entityManager->getRepository(Article::class)->find($id);
    $entityManager->remove($article);
    $entityManager->flush();

    return $this->redirectToRoute('article_list');
}

/**
     * @Route("/category/newCat", name="new_category", methods={"GET", "POST"})
     */
#[Route('/category/newCat', name: 'new_category', methods: ['GET', 'POST'])]
    public function newCategory(Request $request): Response
    {
        $category = new Category();
        $form = $this->createForm(CategoryType::class, $category);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $category = $form->getData();
            $this->entityManager->persist($category);
            $this->entityManager->flush();

            // Ajouter un message de succès ou de redirection
        }
        return $this->render('articles/newCategory.html.twig', [
            'form' => $form->createView(),
        ]);
    }
 /**
 * @Route("/art_cat/", name="article_par_cat")
 * Method({"GET", "POST"})
 */
#[Route('article_par_cat', name: 'article_par_cat', methods: ['GET', 'POST'])]
public function articlesParCategorie(Request $request) {
    $categorySearch = new CategorySearch();
    $form = $this->createForm(CategorySearchType::class,$categorySearch);
    $form->handleRequest($request);
    $articles= [];
    if($form->isSubmitted() && $form->isValid()) {
        $category = $categorySearch->getCategory();
       
        if ($category!="")
       $articles= $category->getArticles();
        else
        $articles= $this->getDoctrine()->getRepository(Article::class)->findAll();
        }
       
        return $this->render('articles/articlesParCategorie.html.twig',['form' => $form->createView(),'articles' => $articles]);
   }



/**
 * @Route("/art_prix/", name="article_par_prix")
 * Method({"GET"})
 */
#[Route('article_par_prix', name: 'article_par_prix', methods: ['GET', 'POST'])]
    public function articlesParPrix(Request $request): Response
    {
        $priceSearch = new PriceSearch();
        $form = $this->createForm(PriceSearchType::class, $priceSearch);
        $form->handleRequest($request);
        $articles = [];

        if ($form->isSubmitted() && $form->isValid()) {
            $minPrice = $priceSearch->getMinPrice();
            $maxPrice = $priceSearch->getMaxPrice();

            $articles = $this->articleRepository->findByPriceRange($minPrice, $maxPrice);
        }

        return $this->render('articles/articlesParPrix.html.twig', [
            'form' => $form->createView(),
            'articles' => $articles
        ]);
    }

}
?>